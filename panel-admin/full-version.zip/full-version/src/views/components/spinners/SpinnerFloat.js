// ** Reactstrap Imports
import { Spinner } from 'reactstrap'

const SpinnerFloat = () => {
  return <Spinner className='float-end mb-2' />
}
export default SpinnerFloat
