// ** Reducers Imports
import layout from "./layout";
import navbar from "./navbar";

const rootReducer = { navbar, layout };

export default rootReducer;
